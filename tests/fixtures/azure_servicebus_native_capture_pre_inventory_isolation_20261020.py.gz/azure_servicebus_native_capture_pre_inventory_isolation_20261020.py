def capture(monkeypatch,cid,branch='positive',data=None):
    data=native(cid,branch=='opposite') if data is None else data
    wire=Wire(data,'normal' if branch in ('positive','opposite') else branch)
    monkeypatch.setattr(azure,'build_opener',lambda *a:wire)
    transport=object.__new__(REAL_TRANSPORT);transport.tenant=transport.verified_tenant=TENANT;transport.owned=False;transport.credential=None
    transport.token=lambda audience:'offline-native' if audience in (azure.ARM,azure.GRAPH) else pytest.fail('unexpected credential audience')
    monkeypatch.setattr(azure,'AzureTransport',lambda auth:transport)
    snapshot=archived.collect_snapshot({'connector':{'provider':'azure','scopes':[SUB],'auth':{'tenant_id':TENANT},'options':{'retries':0,'concurrency':1}},'checks':[cid]})
    findings=archived.evaluate_snapshot(snapshot,checks=[cid])['findings']
    serial={k:({'error':str(v)} if isinstance(v,BaseException) else v)for k,v in data.items()}
    digest=hashlib.sha256(json.dumps(serial,sort_keys=True).encode()).hexdigest()
    node=os.environ.get('PYTEST_CURRENT_TEST','').split(' (')[0]
    entry={'id':cid,'branch':branch,'testnode':node,'native_sha256':digest,'statuses':sorted({f['status']for f in findings}),'requests':wire.calls,'findings':findings}
    RECEIPTS.append(entry)
    if folder:=os.environ.get('AZURE_REMAINING2_RECEIPTS'):
        Path(folder).mkdir(parents=True,exist_ok=True)
        path=Path(folder,cid+'.'+branch+'.'+digest[:12]+'.snapshot.json');path.write_text(json.dumps(snapshot,separators=(',',':'))+'\n');entry['snapshot']=str(path)
    assert wire.calls
    return snapshot,findings,wire
